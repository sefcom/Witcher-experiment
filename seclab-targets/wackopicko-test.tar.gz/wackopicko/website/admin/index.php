<?php

$page = $_GET['page'] . '.php';
require_once($page);

?>
<?php
  // Terrible hack, but allows us to get around duplicating the view code.
$usercheck = False;
include("view.php");

?>
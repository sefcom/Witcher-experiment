<?php

$username = "wackopicko";
$pass = "webvuln!@#";
$database = "wackopicko";

require_once("database.php");
$db = new DB("127.0.0.1", $username, $pass, $database);


?>
<?php
// LEGACY FILE FOR COMPATIBILTY
require($oscTemplate->getFile('template_top.php'));
?>
